<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelInformasi extends Model
{
    protected $table = 'informasi';
    protected $primaryKey = 'id_informasi';
}
