<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelSlide extends Model
{
    protected $table = 'slide';
    protected $primaryKey = 'id_slide';
}
