<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelSubCatering extends Model
{
    protected $table = 'subcatering';
    protected $primaryKey = 'id_subcatering';
}
