<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelCatering extends Model
{
    protected $table = 'catering';
    protected $primaryKey = 'id_catering';
}
