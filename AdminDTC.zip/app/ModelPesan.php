<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelPesan extends Model
{
    protected  $table = 'pesan';
    protected $primaryKey = 'id_pesan';
}
